#!/bin/bash
#

# docker stop container:
docker stop myfedora-mdb2

# docker container remove:
docker rm myfedora-mdb2

# docker image remove:
docker rmi myfedora-mariadb2:v1
