#!/bin/bash
#

# docker stop container:
docker stop myfedora1

# docker remove:
docker rm myfedora1

# docker image remove:
docker rmi myfedora-ssh:v1
