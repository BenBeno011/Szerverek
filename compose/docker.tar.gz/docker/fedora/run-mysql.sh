#!/bin/bash
#
# Dockerfile: custom, own image creating
#
# build image:
docker build -t myfedora-mysql:v1 -f ./Dockerfile-mysql .

# docker create container:
docker create -it -v /home/admin:/shared -p 33006:3306 --name myfedora-mysql --hostname myfedora-mysql myfedora-mysql:v1

# docker start container:
docker start myfedora-mysql
