#!/bin/bash
#

# docker stop container:
docker stop myfedora-mysql

# docker container remove:
docker rm myfedora-mysql

# docker image remove:
docker rmi myfedora-mysql:v1
