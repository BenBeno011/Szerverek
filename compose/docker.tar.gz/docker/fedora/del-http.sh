#!/bin/bash
#

# docker stop container:
docker stop myfedora2

# docker container remove:
docker rm myfedora2

# docker image remove:
docker rmi myfedora-http:v1
