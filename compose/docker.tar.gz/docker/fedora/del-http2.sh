#!/bin/bash
#

# docker stop container:
docker stop myfedora22

# docker container remove:
docker rm myfedora22

# docker image remove:
docker rmi myfedora-http2:v1
