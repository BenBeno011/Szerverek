#!/bin/bash
#
# Dockerfile: custom, own image creating
#
# build image:
docker build -t myfedora-mariadb:v1 -f ./Dockerfile-mariadb .

# docker create container:
docker create -it -v /home/admin:/shared -p 33066:3306 --name myfedora-mdb --hostname myfedora-mdb myfedora-mariadb:v1

# docker start container:
docker start myfedora-mdb
