#!/bin/bash

# docker.service, docker.socket

# stop container:
docker stop fedora-flask

# remove container:
docker rm fedora-flask

# remove image:
docker rmi myfedora-flask:v1
