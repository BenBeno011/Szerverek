#!/bin/bash
#
# Dockerfile: custom, own image creating
#
# build image:
docker build -t myfedora-mariadb2:v1 -f ./Dockerfile-mariadb2 .

# docker create container:
docker create -it -v /home/admin:/shared -p 33066:3306 --name myfedora-mdb2 --hostname myfedora-mdb2 myfedora-mariadb2:v1

# docker start container:
docker start myfedora-mdb2

# docker exec
sleep 5
docker exec -it myfedora-mdb2 /bin/bash -c "mysql < /SQL.txt"
