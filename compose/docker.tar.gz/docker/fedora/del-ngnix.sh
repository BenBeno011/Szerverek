#!/bin/bash
#

# docker stop container:
docker stop myfedora-nginx

# docker container remove:
docker rm myfedora-nginx

# docker image remove:
docker rmi myfedora-nginx:v1
