#!/bin/bash
#
# Dockerfile: custom, own image creating
#
# build image:
docker build -t myfedora-http:v1 -f ./Dockerfile-http .

# docker create container:
docker create -it -v /home/admin:/shared -p 8000:80 -p 4430:443 --name myfedora2 --hostname myfedora2 myfedora-http:v1

# docker start container:
docker start myfedora2
