#!/bin/bash
#

# docker stop container:
docker stop myfedora-mdb

# docker container remove:
docker rm myfedora-mdb

# docker image remove:
docker rmi myfedora-mariadb:v1
