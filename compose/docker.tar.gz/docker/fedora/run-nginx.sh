#!/bin/bash
#
# Dockerfile: custom, own image creating
#
# build image:
docker build -t myfedora-nginx:v1 -f ./Dockerfile-nginx .

# docker create container:
docker create -it -v /home/admin:/shared -p 8080:80 -p 4430:443 --name myfedora-nginx --hostname myfedora-nginx myfedora-nginx:v1

# docker start container:
docker start myfedora-nginx
