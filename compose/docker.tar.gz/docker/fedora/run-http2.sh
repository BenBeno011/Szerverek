#!/bin/bash
#
# Dockerfile: custom, own image creating
#
# build image:
docker build -t myfedora-http2:v1 -f ./Dockerfile-http2 .

# docker create container:
docker create -it -v /home/admin:/shared -v /home/admin/docker/fedora/www:/var/www/html -p 8001:80 -p 4433:443 \
  --name myfedora22 --hostname myfedora22 myfedora-http2:v1

# docker start container:
docker start myfedora22
