#!/bin/bash
#
# Dockerfile: custom, own image creating
#
# build image:
docker build -t myfedora-ssh:v1 -f ./Dockerfile-ssh .

# docker create container:
docker create -it -v /home/admin:/shared -p 2022:22 --name myfedora1 --hostname myfedora1 myfedora-ssh:v1

# docker start container:
docker start myfedora1
