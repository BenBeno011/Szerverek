-----------------------------
Python Flask konténer Network
-----------------------------

 * Használata:

   ./first-run.sh
   ./run.sh install           { remove }
   ./run-mdb.sh install       { remove }


 * Tesztelés:

   curl http://127.0.0.1:5005


 * Működés:

    A 'first-run.sh' létrehozza a network-t.
    A konténerek név szerint is látják egymást: mdb1, flasknetwork1
