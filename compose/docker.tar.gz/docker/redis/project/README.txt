---------------
 Docker Redis
---------------


 * Image: redis:latest


 * Használat:

     ./run.sh install
     ./run.sh remove


 * Teszt:

    futtatás:    python ./app.py


