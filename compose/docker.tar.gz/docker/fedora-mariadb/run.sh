#!/bin/bash

docker build -t fedora-mariadb2:v1 .
docker run -d --env-file db.env -p 3366:3306 --name fedora-mariadb2 --hostname fedora-mariadb2 fedora-mariadb2:v1
