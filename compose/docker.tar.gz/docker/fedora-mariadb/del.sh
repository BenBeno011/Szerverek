#!/bin/bash

docker stop fedora-mariadb2
docker rm fedora-mariadb2
docker rmi fedora-mariadb2:v1
