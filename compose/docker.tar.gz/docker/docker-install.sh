#!/bin/bash
#
# Install Docker Engine
#

sudo dnf -y install dnf-plugins-core
sudo dnf-3 config-manager --add-repo https://download.docker.com/linux/fedora/docker-ce.repo -y
sudo dnf install docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin -y

# add user to group 'docker'
# add user to group 'vboxsf'
# note: newgrp docker vboxsf
#
# cp daemon.json /etc/docker/daemon.json
#
# firewall-cmd --zone=docker --add-interface=docker0 --permanent
#
# systemctl enable docker docker.socket

