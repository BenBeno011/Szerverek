---------------
GOLANG konténer
---------------


 * Multistage!


 * Image: golang


 * Használata:

   ./run.sh install
   ./run.sh remove


 * Tesztelés:

   curl http://127.0.0.1:8080/hello

