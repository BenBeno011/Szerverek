
#   $ go build http-server.go

$ go run http-server.go &
Access the /hello route.

$ curl localhost:8080/hello
hello
