--------------
SAMBA konténer
--------------


 * https://hub.docker.com/r/dockurr/samba


 * Használata:

   ./run.sh install
   ./run.sh remove


 * Tesztelés:

   mount.cifs \\\\ip_addr\\Data /home/admin/docker/samba/mnt -o user=samba

