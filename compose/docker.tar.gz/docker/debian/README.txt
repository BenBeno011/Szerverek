---------------
Debian konténer
---------------


 * Használata:

   ./run.sh install
   ./run.sh remove


 * Teszt:

   docker exec -it debian11 /bin/bash


