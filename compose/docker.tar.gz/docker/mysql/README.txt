--------------
MySQL konténer
--------------


 * Használata:

   ./run.sh install
   ./run.sh remove


 * Kapcsolódás a MySQL szerverhez:

   mysql -u root -p123456 -h 127.0.0.1 -P 3306


