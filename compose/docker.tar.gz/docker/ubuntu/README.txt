---------------
Ubuntu konténer
---------------


 * Használata:

   ./run.sh install
   ./run.sh remove


 * Teszt:

   docker exec -it ubuntu1 /bin/bash


