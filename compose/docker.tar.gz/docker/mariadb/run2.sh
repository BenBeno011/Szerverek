#!/usr/bin/env bash

set -e

IMAGE_NAME="mymariadb"
IMAGE_TAG="v2"
FULL_IMAGE="${IMAGE_NAME}:${IMAGE_TAG}"
CONTAINER_NAME="mariadb2"
HOSTNAME_NAME="mariadb2"
VOLUME_MAPPING="/home/admin/docker/mariadb/lib:/var/lib/mysql"
PORT_MAPPING="33006:3306"
PASSWORD="12345678"
DOCKERFILE="./Dockerfile2"

# Usage
usage() {
    echo "Használat: $0 {install|remove}"
    exit 1
}

# Check params
if [ $# -ne 1 ]; then
    usage
fi


# Options
case "$1" in
    install)
        echo "[INFO] Docker image build..."
        docker build -t "$FULL_IMAGE" -f $DOCKERFILE .

        echo "[INFO] Container létrehozása..."
        docker create -it \
            -v "$VOLUME_MAPPING" \
            -p "$PORT_MAPPING" \
            --name "$CONTAINER_NAME" \
            --hostname "$HOSTNAME_NAME" \
            -e MARIADB_ROOT_PASSWORD="$PASSWORD" \
            "$FULL_IMAGE"

        echo "[INFO] Container indítása..."
        docker start "$CONTAINER_NAME"
        ;;

    remove)
        echo "[INFO] Container leállítása és törlése..."
        docker stop "$CONTAINER_NAME" || true
        docker rm "$CONTAINER_NAME" || true

        echo "[INFO] Image törlése..."
        docker rmi "$FULL_IMAGE" || true
        ;;

    *)
        usage
        ;;
esac
