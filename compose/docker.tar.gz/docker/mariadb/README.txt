----------------
MariaDB konténer
----------------


 * Használata:

   ./run.sh install
   ./run.sh remove

   ./run2.sh install
   ./run2.sh remove



 * Kapcsolódás a MariaDB szerverhez:

   mysql -u root -p123456 -h 127.0.0.1 -P 3306


