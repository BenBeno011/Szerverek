#!/bin/bash

# build
docker build -t mynginx:v1 -f ./Dockerfile .

# create
docker create -it -v /home/admin/docker/nginx/html:/usr/share/nginx/html -p 8081:80 --name nginx1 --hostname nginx1 mynginx:v1

# run
docker start nginx1

