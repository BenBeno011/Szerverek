#!/bin/bash

# build
docker build -t mynginx:v2 -f ./Dockerfile2 .

# create
docker create -it -v /home/admin/docker:/shared -p 8082:80 --name nginx2 --hostname nginx2 mynginx:v2

# run
docker start nginx2

